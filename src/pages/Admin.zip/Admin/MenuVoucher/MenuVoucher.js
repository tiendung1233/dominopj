function MenuVoucher() {
    return ( <></> );
}

export default MenuVoucher;